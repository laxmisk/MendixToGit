//>>built
define("dijit/form/nls/fr/ComboBox",({previousMessage:"Choix précédents",nextMessage:"Plus de choix"}));
