//>>built
define("dijit/_base/sniff",["dojo/uacss"],function(){
});
