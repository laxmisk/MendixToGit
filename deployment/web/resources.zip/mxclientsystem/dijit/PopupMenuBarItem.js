//>>built
define("dijit/PopupMenuBarItem",["dojo/_base/declare","./PopupMenuItem","./MenuBarItem"],function(_1,_2,_3){
var _4=_3._MenuBarItemMixin;
return _1("dijit.PopupMenuBarItem",[_2,_4],{});
});
